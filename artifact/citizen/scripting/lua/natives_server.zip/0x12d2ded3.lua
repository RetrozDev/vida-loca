--- START_FIND_KVP
-- @param prefix A prefix match
-- @return A KVP find handle to use with [FIND_KVP](#\_0xBD7BEBC5) and close with [END_FIND_KVP](#\_0xB3210203)
function Global.StartFindKvp(prefix)
	return _in(0xdd379006, _ts(prefix), _ri)
end
