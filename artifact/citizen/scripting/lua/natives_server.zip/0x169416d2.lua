--- TASK_WARP_PED_INTO_VEHICLE
-- @param seatIndex See eSeatPosition declared in [`IS_VEHICLE_SEAT_FREE`](#\_0x22AC59A870E6A669).
function Global.TaskWarpPedIntoVehicle(ped, vehicle, seatIndex)
	return _in(0x65d4a35d, ped, vehicle, seatIndex)
end
