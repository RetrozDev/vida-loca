--- GET_TRAIN_CARRIAGE_INDEX
-- @param train The entity handle.
-- @return The carriage index. -1 returned if invalid result.
function Global.GetTrainCarriageIndex(train)
	return _in(0x4b8285cf, train, _ri)
end
