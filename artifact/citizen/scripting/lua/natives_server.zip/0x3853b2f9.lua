--- GET_INSTANCE_ID
function Global.GetInstanceId()
	return _in(0x9f1c4383, _ri)
end
