--- Cancels the currently executing event.
function Global.CancelEvent()
	return _in(0xfa29d35d)
end
