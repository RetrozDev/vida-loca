--- Only works for vehicle and peds
-- @param entity The entity to check the health of
-- @return If the entity is a vehicle it will return 0-1000
-- 		If the entity is a ped it will return 0-200
-- 		If the entity is an object it will return 0
function Global.GetEntityHealth(entity)
	return _in(0x8e3222b7, entity, _ri)
end
