--- GET_VEHICLE_COLOURS
function Global.GetVehicleColours(vehicle)
	return _in(0x40d82d88, vehicle, _i, _i)
end
