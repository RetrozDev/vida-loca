--- A getter for [FREEZE_ENTITY_POSITION](#\_0x428CA6DBD1094446).
-- @param entity The entity to check for
-- @return Boolean stating if it is frozen or not.
function Global.IsEntityPositionFrozen(entity)
	return _in(0xedbe6add, entity, _r)
end
