--- DOES_ENTITY_EXIST
function Global.DoesEntityExist(entity)
	return _in(0x3ac90869, entity, _r)
end
