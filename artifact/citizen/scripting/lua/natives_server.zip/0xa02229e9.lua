--- GET_PED_ARMOUR
function Global.GetPedArmour(ped)
	return _in(0x2ce311a7, ped, _ri)
end
