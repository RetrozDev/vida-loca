--- GET_HOST_ID
function Global.GetHostId()
	return _in(0x5f70f5a3, _s)
end
