--- IS_PLAYER_USING_SUPER_JUMP
-- @param playerSrc The player handle
-- @return A boolean.
function Global.IsPlayerUsingSuperJump(playerSrc)
	return _in(0xc7d2c20c, _ts(playerSrc), _r)
end
