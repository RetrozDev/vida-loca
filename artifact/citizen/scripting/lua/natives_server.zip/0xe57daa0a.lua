--- GET_ENTITY_ROTATION_VELOCITY
function Global.GetEntityRotationVelocity(entity)
	return _in(0x9bf8a73f, entity, _rv)
end
