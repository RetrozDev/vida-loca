--- GET_AIR_DRAG_MULTIPLIER_FOR_PLAYERS_VEHICLE
-- @param playerSrc The player handle
function Global.GetAirDragMultiplierForPlayersVehicle(playerSrc)
	return _in(0x62fc38d0, _ts(playerSrc), _rf)
end
