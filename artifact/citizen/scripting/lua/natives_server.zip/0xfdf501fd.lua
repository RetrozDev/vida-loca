--- GET_VEHICLE_PETROL_TANK_HEALTH
function Global.GetVehiclePetrolTankHealth(vehicle)
	return _in(0xe41595ce, vehicle, _rf)
end
